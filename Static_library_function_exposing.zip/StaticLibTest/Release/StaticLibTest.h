#pragma once
#include "pch.h"

__declspec(dllexport) void fnStaticLibTest();