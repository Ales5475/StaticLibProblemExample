// StaticLibTest.cpp : Defines the functions for the static library.
//

#include "pch.h"
// TODO: This is an example of a library function
void fnStaticLibTest(){
	printf("Hello World! (Static library from another project)\n");
}
