#include "pch.h"
#include "StaticLibrary.h"
#include "StaticLibTest.h"

inline void DllTestFunct() {
	fnStaticLibrary();
	fnStaticLibTest();
	printf("Hello world (Dynamic library)!\n");
}