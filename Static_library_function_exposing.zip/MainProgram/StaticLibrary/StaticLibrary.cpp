// StaticLibrary.cpp : Defines the functions for the static library.
//

#include "pch.h"

inline void fnStaticLibrary(){
	printf("Hello world (Static library)!\n");
}
